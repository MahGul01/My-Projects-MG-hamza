Welcome
========

This is a sample node project.

To run this project:

- Type `node app.js` in the terminal

Cheers.
